# SimpleRcScanner

<a href="http://test.sui.li/oszi">Demo</a>

The script requires data in which the first level is always low. Otherwise the plot will be vertically flipped.
You can also paste data on the first line of ReceivedSignalVisualizer.ods LibreOffice Calc spreadsheet. Only the first 50 timings will be plotted.
