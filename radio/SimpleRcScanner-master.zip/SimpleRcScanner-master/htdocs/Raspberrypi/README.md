# SimpleRcScanner for Raspberry pi

compile with:
`gcc SimpleRcScannerrpi.cpp -o SimpleRcScannerrpi -lwiringPi`

use:
`sudo ./SimpleRcScannerrpi`

You will need to install wiringpi (check 433Utils for instructions).
